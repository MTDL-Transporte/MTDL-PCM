#!/usr/bin/env python3
"""
Script para atualizar o banco de dados com a nova coluna maintenance_cause
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from sqlalchemy import create_engine, text
from app.database import DATABASE_URL

def update_database():
    """Atualizar banco de dados com nova coluna"""
    engine = create_engine(DATABASE_URL)
    
    try:
        with engine.connect() as conn:
            # Verificar se a coluna já existe
            result = conn.execute(text("PRAGMA table_info(work_orders)")).fetchall()
            columns = [row[1] for row in result]
            
            if 'maintenance_cause' not in columns:
                print("Adicionando coluna maintenance_cause...")
                conn.execute(text("ALTER TABLE work_orders ADD COLUMN maintenance_cause VARCHAR(50)"))
                conn.commit()
                print("✅ Coluna maintenance_cause adicionada com sucesso!")
            else:
                print("✅ Coluna maintenance_cause já existe!")
                
            print("\nColunas atuais da tabela work_orders:")
            result = conn.execute(text("PRAGMA table_info(work_orders)")).fetchall()
            for row in result:
                print(f"  - {row[1]}: {row[2]}")
                
    except Exception as e:
        print(f"❌ Erro ao atualizar banco de dados: {e}")
        return False
    
    return True

if __name__ == "__main__":
    print("🔧 Atualizando banco de dados MTDL-PCM...")
    if update_database():
        print("✅ Banco de dados atualizado com sucesso!")
    else:
        print("❌ Falha ao atualizar banco de dados!")