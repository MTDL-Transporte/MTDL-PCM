"""
MTDL-PCM - Sistema de Manutenção e Controle de Equipamentos
Aplicação principal FastAPI
"""

from fastapi import FastAPI, Request, Depends
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, RedirectResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response
import uvicorn
import os
from dotenv import load_dotenv
from contextlib import asynccontextmanager
from app.models.idempotency import IdempotencyRecord

# Carregar variáveis de ambiente do .env (antes de importar o banco)
load_dotenv()

# Importar configuração do banco de dados
from app.database import engine, Base, get_db

# Importar routers
from app.routers import dashboard, maintenance, warehouse, reports, hr, construction
from app.routers.sync import router as sync_router

# Importar modelos para criar as tabelas
from app.models.equipment import Equipment, HorimeterLog
from app.models.maintenance import WorkOrder, MaintenancePlan, TimeLog, MaintenancePlanMaterial, WorkOrderMaterial
from app.models.warehouse import Material, Supplier, StockMovement, PurchaseRequest, PurchaseRequestItem, Quotation, QuotationItem
from app.models.hr import Employee


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Middleware para adicionar headers de segurança"""
    
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        
        # Content Security Policy
        csp = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; "
            "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; "
            "img-src 'self' data: https:; "
            "font-src 'self' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; "
            "connect-src 'self' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; "
            "frame-ancestors 'none'; "
            "base-uri 'self'; "
            "form-action 'self'"
        )
        
        # Adicionar headers de segurança
        response.headers["Content-Security-Policy"] = csp
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
        
        return response


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Gerenciar ciclo de vida da aplicação"""
    # Startup
    print("🚀 Iniciando MTDL-PCM...")
    
    # Criar tabelas do banco de dados
    print("📊 Criando tabelas do banco de dados...")
    Base.metadata.create_all(bind=engine)
    print("✅ Tabelas criadas com sucesso!")
    # Migração simples: garantir colunas ausentes na tabela purchase_requests (SQLite)
    try:
        if "sqlite" in str(engine.url):
            from sqlalchemy import text
            with engine.connect() as conn:
                cols = {row[1] for row in conn.execute(text("PRAGMA table_info('purchase_requests')"))}
                if 'cost_center' not in cols:
                    conn.execute(text("ALTER TABLE purchase_requests ADD COLUMN cost_center VARCHAR(100)"))
                if 'stock_justification' not in cols:
                    conn.execute(text("ALTER TABLE purchase_requests ADD COLUMN stock_justification TEXT"))
                if 'total_value' not in cols:
                    conn.execute(text("ALTER TABLE purchase_requests ADD COLUMN total_value FLOAT DEFAULT 0.0"))
                if 'approved_date' not in cols:
                    conn.execute(text("ALTER TABLE purchase_requests ADD COLUMN approved_date DATETIME"))
                if 'approved_by' not in cols:
                    conn.execute(text("ALTER TABLE purchase_requests ADD COLUMN approved_by VARCHAR(100)"))
            print("🔄 Migração automática aplicada para purchase_requests (SQLite).")
            # Migração automática: adicionar coluna hr_matricula em technicians
            with engine.connect() as conn:
                tech_cols = {row[1] for row in conn.execute(text("PRAGMA table_info('technicians')"))}
                if 'hr_matricula' not in tech_cols:
                    conn.execute(text("ALTER TABLE technicians ADD COLUMN hr_matricula INTEGER"))
            print("🔄 Migração automática aplicada para technicians.hr_matricula (SQLite).")
            # Migração automática: adicionar colunas em stock_movements
            with engine.connect() as conn:
                sm_cols = {row[1] for row in conn.execute(text("PRAGMA table_info('stock_movements')"))}
                if 'cost_center' not in sm_cols:
                    conn.execute(text("ALTER TABLE stock_movements ADD COLUMN cost_center VARCHAR(100)"))
                if 'equipment_id' not in sm_cols:
                    conn.execute(text("ALTER TABLE stock_movements ADD COLUMN equipment_id INTEGER"))
                if 'application' not in sm_cols:
                    conn.execute(text("ALTER TABLE stock_movements ADD COLUMN application VARCHAR(200)"))
            print("🔄 Migração automática aplicada para stock_movements (SQLite).")
            # Migração automática: adicionar colunas em equipments
            with engine.connect() as conn:
                eq_cols = {row[1] for row in conn.execute(text("PRAGMA table_info('equipments')"))}
                if 'company_name' not in eq_cols:
                    conn.execute(text("ALTER TABLE equipments ADD COLUMN company_name VARCHAR(10)"))
                if 'demobilization_date' not in eq_cols:
                    conn.execute(text("ALTER TABLE equipments ADD COLUMN demobilization_date DATETIME"))
                # Adicionar coluna category para equipamentos (tipo do equipamento)
                if 'category' not in eq_cols:
                    conn.execute(text("ALTER TABLE equipments ADD COLUMN category VARCHAR(100)"))
                # Adicionar coluna fleet (frota: Propria/Terceirizada)
                if 'fleet' not in eq_cols:
                    conn.execute(text("ALTER TABLE equipments ADD COLUMN fleet VARCHAR(20)"))
                # Adicionar coluna cnpj (identificação da empresa)
                if 'cnpj' not in eq_cols:
                    conn.execute(text("ALTER TABLE equipments ADD COLUMN cnpj VARCHAR(18)"))
                # Adicionar coluna company_legal_name (razão social)
                if 'company_legal_name' not in eq_cols:
                    conn.execute(text("ALTER TABLE equipments ADD COLUMN company_legal_name VARCHAR(200)"))
                # Adicionar coluna monthly_quota (franquia mensal de horas)
                if 'monthly_quota' not in eq_cols:
                    conn.execute(text("ALTER TABLE equipments ADD COLUMN monthly_quota FLOAT"))
            print("🔄 Migração automática aplicada para equipments (SQLite).")
    except Exception as e:
        print(f"⚠️ Falha ao aplicar migração automática: {e}")

    # Reconciliação preventiva inicial com base nos dados existentes
    try:
        from app.database import SessionLocal
        from app.models.equipment import Equipment
        from app.routers.maintenance import check_and_create_preventive_maintenance

        db = SessionLocal()
        equipments = db.query(Equipment).filter(
            Equipment.initial_horimeter != None,
            Equipment.current_horimeter != None
        ).all()

        total_orders = 0
        total_alerts = 0

        for equipment in equipments:
            result = await check_and_create_preventive_maintenance(equipment, db)
            if isinstance(result, dict):
                total_orders += result.get("orders_created", 0)
                total_alerts += result.get("alerts_created", 0)

        db.close()
        print(f"🔎 Reconciliação preventiva inicial concluída: {total_orders} OS, {total_alerts} alertas.")
    except Exception as e:
        print(f"⚠️ Falha na reconciliação preventiva inicial: {e}")
    
    yield
    
    # Shutdown
    print("🛑 Encerrando MTDL-PCM...")


# Criar instância do FastAPI
app = FastAPI(
    title="MTDL-PCM",
    description="Sistema de Manutenção e Controle de Equipamentos",
    version="1.0.0",
    lifespan=lifespan
)

class IdempotencyMiddleware(BaseHTTPMiddleware):
    """Middleware para idempotência em rotas de API mutáveis.
    Usa header 'X-Idempotency-Key' para retornar a mesma resposta
    quando a operação já foi realizada com o mesmo payload.
    """
    async def dispatch(self, request: Request, call_next):
        path = request.url.path
        method = request.method.upper()
        # Somente para rotas de API mutáveis
        if not path.startswith('/api/') or method not in ('POST','PUT','PATCH','DELETE'):
            return await call_next(request)
        key = request.headers.get('X-Idempotency-Key')
        if not key:
            return await call_next(request)
        # Ler o corpo da requisição e calcular hash
        body = await request.body()
        try:
            import hashlib
            body_hash = hashlib.sha256(body or b'').hexdigest()
        except Exception:
            body_hash = 'no-body'
        # Checar registro existente
        from app.database import SessionLocal
        db = SessionLocal()
        try:
            existing = db.query(IdempotencyRecord).filter_by(
                key=key, method=method, path=path, body_hash=body_hash
            ).first()
        finally:
            db.close()
        if existing:
            # Retornar resposta previamente armazenada
            return Response(content=existing.response_body or '', status_code=existing.status_code, media_type='application/json')
        # Repassar a requisição (reconstituindo o corpo)
        async def receive():
            return {'type': 'http.request', 'body': body, 'more_body': False}
        request = Request(request.scope, receive)
        response = await call_next(request)
        # Capturar corpo da resposta
        resp_body = b''
        async for chunk in response.body_iterator:
            resp_body += chunk
        # Armazenar resposta para a chave
        db2 = SessionLocal()
        try:
            rec = IdempotencyRecord(
                key=key,
                method=method,
                path=path,
                body_hash=body_hash,
                status_code=response.status_code,
                response_body=resp_body.decode('utf-8', errors='ignore')
            )
            db2.add(rec)
            db2.commit()
        except Exception as e:
            db2.rollback()
            print('⚠️ Falha ao salvar idempotência:', e)
        finally:
            db2.close()
        # Retornar resposta com corpo reconstruído
        return Response(content=resp_body, status_code=response.status_code, headers=dict(response.headers), media_type=response.media_type)

# Configurar middlewares de segurança
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(IdempotencyMiddleware)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configurar arquivos estáticos e templates com cache busting
app.mount("/static", StaticFiles(directory="static"), name="static")

# Adicionar função para cache busting
import time
# Importar configuração de templates
from app.templates_config import templates

# Incluir routers
app.include_router(dashboard.router, prefix="", tags=["Dashboard"])
app.include_router(dashboard.router, prefix="/api/dashboard", tags=["Dashboard API"])
app.include_router(maintenance.router, prefix="/api/maintenance", tags=["Manutenção API"])
app.include_router(warehouse.router, prefix="/api/warehouse", tags=["Almoxarifado API"])
app.include_router(reports.router, prefix="/api/reports", tags=["Relatórios API"])
app.include_router(hr.router, prefix="", tags=["RH API"])
app.include_router(construction.router, prefix="", tags=["Apropriação de Obra"]) 
app.include_router(sync_router, prefix="/api/sync", tags=["Sync API"])

# Incluir routers para páginas HTML
app.include_router(maintenance.router, prefix="/maintenance", tags=["Manutenção Páginas"])
app.include_router(maintenance.router, prefix="/equipment", tags=["Equipamentos"])
app.include_router(warehouse.router, prefix="/warehouse", tags=["Almoxarifado Páginas"])
app.include_router(warehouse.router, prefix="/inventory", tags=["Inventário"])
app.include_router(reports.router, prefix="/reports", tags=["Relatórios Páginas"])


@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    """Página inicial - redireciona para dashboard"""
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/health")
async def health_check():
    """Endpoint para verificação de saúde da aplicação"""
    return {
        "status": "healthy",
        "message": "MTDL-PCM está funcionando corretamente",
        "version": "1.0.0"
    }


@app.get("/favicon.ico")
async def favicon():
    return RedirectResponse(url="/static/img/favicon.svg")

@app.get("/offline", response_class=HTMLResponse)
async def offline_page(request: Request):
    """Página de fallback para navegação em modo offline"""
    return templates.TemplateResponse("offline.html", {"request": request})

@app.exception_handler(404)
async def not_found_handler(request: Request, exc):
    """Handler para páginas não encontradas"""
    return templates.TemplateResponse(
        "error.html", 
        {
            "request": request, 
            "error_code": 404,
            "error_message": "Página não encontrada"
        },
        status_code=404
    )


@app.exception_handler(500)
async def internal_error_handler(request: Request, exc):
    """Handler para erros internos do servidor"""
    import traceback
    tb = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    print("\n===== ERRO 500 DETALHES =====\n", tb)
    # Se for uma rota de API, retornar JSON para facilitar o consumo
    if request.url.path.startswith("/api/"):
        from fastapi.responses import JSONResponse
        return JSONResponse(
            status_code=500,
            content={
                "error_code": 500,
                "error_message": "Erro interno do servidor",
                "detail": str(exc),
            }
        )
    # Caso contrário, retornar página HTML amigável
    return templates.TemplateResponse(
        "error.html",
        {
            "request": request,
            "error_code": 500,
            "error_message": "Erro interno do servidor"
        },
        status_code=500
    )


if __name__ == "__main__":
    # Configurações para desenvolvimento
    print("🔧 MTDL-PCM - Sistema de Manutenção e Controle de Equipamentos")
    print("📍 Acesse: http://localhost:8000")
    print("📚 Documentação da API: http://localhost:8000/docs")
    print("🔍 Redoc: http://localhost:8000/redoc")
    
    # Verificar se o diretório de banco de dados existe
    db_dir = "data"
    if not os.path.exists(db_dir):
        os.makedirs(db_dir)
        print(f"📁 Diretório {db_dir} criado para o banco de dados")
    
    # Executar servidor
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )