$ErrorActionPreference = 'Stop'
$root = (Get-Location).Path
$ts = Get-Date -Format 'yyyyMMdd-HHmmssfff'
$backupDir = $root
$dest = Join-Path $backupDir ("backup-" + $ts + ".zip")
$items = Get-ChildItem -LiteralPath $root -Force | Where-Object { $_.Name -notin @('.venv', '.pytest_cache') -and $_.Name -notmatch '^__pycache__$' }
Compress-Archive -Path $items.FullName -DestinationPath $dest -Force
Get-Item $dest | Select-Object FullName, Length | Format-List