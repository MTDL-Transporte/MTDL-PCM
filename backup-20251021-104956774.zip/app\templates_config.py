"""
Configuração centralizada de templates
"""

import os
from fastapi.templating import Jinja2Templates

# Instância global de templates
templates = Jinja2Templates(directory="templates")

def get_static_url(path: str) -> str:
    """Gerar URL com cache busting para arquivos estáticos"""
    try:
        file_path = os.path.join("static", path.lstrip("/"))
        if os.path.exists(file_path):
            # Usar timestamp de modificação do arquivo para cache busting
            mtime = os.path.getmtime(file_path)
            return f"/static/{path}?v={int(mtime)}"
        else:
            return f"/static/{path}"
    except:
        return f"/static/{path}"

# Adicionar função ao contexto dos templates
templates.env.globals["static_url"] = get_static_url