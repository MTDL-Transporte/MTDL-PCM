# Guia de Instalação – MTDL-PCM

Este guia explica como instalar, executar e atualizar o MTDL-PCM em Windows.

## Requisitos do Sistema
- Windows 10 ou superior (64-bit)
- Porta `8000` (ou escolhida) livre no firewall
- Acesso à internet para verificar atualizações (opcional)
- Sem necessidade de Python instalado ao usar o `.exe`

## Instalação (via .exe)
1. Baixe o instalador/execução única (`MTDL-PCM.exe`) no Google Drive.
2. Mova o arquivo para uma pasta segura (ex.: `C:\MTDL-PCM`).
3. (Opcional) Permita o app no firewall do Windows quando solicitado.
4. Clique duas vezes em `MTDL-PCM.exe` para iniciar o servidor.
5. Abra o navegador e acesse `http://localhost:8000/admin/login`.

## Atualizações
- O sistema verifica automaticamente se há uma versão mais recente ao iniciar.
- Se houver, aparecerá um aviso: “Uma nova versão está disponível. Deseja baixar agora?”
- Ao confirmar, você será direcionado ao link de download (Google Drive).
- Para atualizar, substitua o arquivo `.exe` antigo pelo novo e reinicie.

## Problemas comuns
- Porta ocupada: altere a porta usando a variável de ambiente `PORT` antes de iniciar.
- Firewall bloqueando acesso: permita o app e/ou a porta nas configurações do Windows.
- Sem internet: o sistema funciona, porém não verificará atualizações.

## Suporte e Feedback
- E-mail: `contato@mtdl.com.br`
- Observações: descreva o problema e, se possível, anexe prints ou logs.

## Desenvolvedores (build opcional)
Para gerar o `.exe` localmente:
1. Tenha Python 3.11+ e pip em sua máquina de build.
2. Instale dependências: `pip install -r requirements.txt`.
3. Execute o script:
   - PowerShell: `./scripts/build.ps1 -Version 1.0.1`
4. O executável será gerado em `dist/MTDL-PCM.exe` e copiado para `releases/MTDL-PCM-<versão>`.
5. Publique no Google Drive e atualize `static/version.json` com a `download_url`.