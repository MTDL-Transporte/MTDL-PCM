param(
  [string]$Version = "1.0.0",
  [string]$Name = "MTDL-PCM",
  [string]$Port = "8000"
)

Write-Host "==> Preparando build do instalador: $Name v$Version"

# Escreve versão no arquivo VERSION e exporta env var
$versionFile = Join-Path $PSScriptRoot "..\VERSION"
Set-Content -Path $versionFile -Value $Version -NoNewline
$env:APP_VERSION = $Version

# Limpa saída anterior
if (Test-Path (Join-Path $PSScriptRoot "..\dist")) { Remove-Item -Recurse -Force (Join-Path $PSScriptRoot "..\dist") }
if (Test-Path (Join-Path $PSScriptRoot "..\build")) { Remove-Item -Recurse -Force (Join-Path $PSScriptRoot "..\build") }

# Caminhos de dados (Windows usa ";" para add-data)
$root = Resolve-Path (Join-Path $PSScriptRoot "..")
$templates = Join-Path $root "templates"; if (-Not (Test-Path $templates)) { New-Item -ItemType Directory -Path $templates | Out-Null }
$static = Join-Path $root "static"; if (-Not (Test-Path $static)) { New-Item -ItemType Directory -Path $static | Out-Null }

# Executa PyInstaller em modo onefile
$cmd = @(
  "pyinstaller",
  "--noconfirm",
  "--clean",
  "--onefile",
  "--name", $Name,
  "--hidden-import=uvicorn",
  "--hidden-import=fastapi",
  "--hidden-import=jinja2",
  "--hidden-import=sqlalchemy",
  "--hidden-import=pydantic",
  "--hidden-import=starlette",
  "--add-data", "$templates;templates",
  "--add-data", "$static;static",
  "run.py"
) -join " "

Write-Host "==> Rodando: $cmd"
Invoke-Expression $cmd

# Copia artefato para releases
$releaseDir = Join-Path $root ("releases\" + $Name + "-" + $Version)
if (-Not (Test-Path $releaseDir)) { New-Item -ItemType Directory -Path $releaseDir | Out-Null }
Copy-Item (Join-Path $root ("dist\" + $Name + ".exe")) -Destination $releaseDir -Force

Write-Host "==> Build finalizado. Arquivo: " (Join-Path $releaseDir ($Name + ".exe"))
Write-Host "==> Publique no Google Drive e atualize static/version.json com a URL"